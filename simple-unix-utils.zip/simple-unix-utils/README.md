# Simple Unix Utilities in C

This project contains basic implementations of Unix utilities in C:

- `pwd`: print current working directory
- `echo`: print strings to stdout
- `cp`: copy a file
- `mv`: move/rename a file

## Compilation

Use the following commands:

```bash
gcc -o pwd pwd.c
gcc -o echo echo.c
gcc -o cp cp.c
gcc -o mv mv.c
